package DAO;

public class User {
//    private static String username;
//    private static String password;
    String username="user1234";
    String password="pass1234";
    String name="Anunda";
    private static String firstname;
    private static String lastname;
    private static String telephone;
    private static String address;
    
    public User(String username, String pass, String firstname, String lastname, String telephone, String address){
        this.username = username;
        this.password = pass;
        this.firstname = firstname;
        this.lastname = lastname;
        this.telephone = telephone;
        this.address = address;
    }
    
    public User(){
        this.username = username;
        this.password = password;
    }
    
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
    public static String getFirstname(){
        return firstname;
    }
    public static String getLastname(){
        return lastname;
    }
    public static String getTelephone(){
        return telephone;
    }
    public static String getAddress(){
        return address;
    }
    
    public void Print(){
        System.out.print(username + " " + password + " " + firstname + " " + lastname + " " + telephone + " " + address);
    }
   
    public String getName(){
        return name;
    }
}
