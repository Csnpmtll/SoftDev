/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static DAO.IndexDAO.database;
import Form.FormIndex;
import static Form.FormIndex.fpd;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import java.util.ArrayList;
import java.util.List;
import Form.FormProduct;

public class ProductDAO {

    public static MongoClientURI uri = new MongoClientURI("mongodb://user1234:pass1234@ds127704.mlab.com:27704/softdev");
    public static MongoClient mongoClient = new MongoClient(uri);
    public static DB database = mongoClient.getDB("softdev");
    ArrayList<Product> pd = new ArrayList<>();
    User user = new User();

    public ArrayList<Product> getProduct(int idx) {
        try {
            DBCollection collection = database.getCollection("product");
            BasicDBObject query = new BasicDBObject();
            query.put("_id", idx);
            DBCursor cursor = collection.find(query);
            ArrayList<Product> product = new ArrayList<>();
            while (cursor.hasNext()) {
                DBObject obj = cursor.next();
                int id = (int) obj.get("_id");
                String productName = (String) obj.get("name");
                List size = (List) obj.get("size");
                int quantity = (int) obj.get("quantity");
                int price = (int) obj.get("price");
                String description = (String) obj.get("description");
                int soldout = (int) obj.get("soldout");
                product.add(new Product(id, productName, size, quantity, price, description, soldout));
            }
            return product;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void addToCart(Product product) {

        DBCollection collection = database.getCollection("cart");
        BasicDBObject query = new BasicDBObject();
        query.put("name", fpd.txt_ProductName.getText());
        query.put("size", Integer.parseInt(fpd.ComboBox_Size.getSelectedItem().toString()));
        query.put("price", Integer.parseInt(fpd.txt_Price.getText()));
        query.put("quantity", Integer.parseInt(fpd.ComboBox_Quantity.getSelectedItem().toString()));
        query.put("username", user.getUsername());
        collection.insert(query);
    }

    public int checkProductQuantity(Product product) {
        DBCollection collection = database.getCollection("product");
        BasicDBObject query = new BasicDBObject();
        query.put("name", product.getProductName());
        DBCursor cursor = collection.find(query);
        int qty = (int) cursor.one().get("quantity");
        System.out.println(qty);
        return qty;
    }

    public boolean checkProductQTY(String name, int qty) {
        DBCollection table = database.getCollection("product");
        boolean flag = false;
        BasicDBObject searchQuery = new BasicDBObject();
        searchQuery.append("name", name);
        DBCursor cursor = table.find(searchQuery);
        DBObject ob = cursor.next();
        int qtyProduct = Integer.parseInt(ob.get("quantity").toString());
        if (qty <= qtyProduct) {
            flag = true;
        }
        return flag;

    }

}
