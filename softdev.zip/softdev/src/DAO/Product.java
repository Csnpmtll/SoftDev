/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.util.List;

/**
 *
 * @author Boss
 */
public class Product {
    public int id;
    public String productName;
    public String name;
    public List size;
    public int size1;
    public int quantity;
    public int price;
    public String description; 
    public int soldout;
    Product(int id,String productName, List size, int quantity, int price, String description, int soldout) {
        this.id=id;
        this.productName=productName;
        this.size=size;
        this.quantity=quantity;
        this.price=price;
        this.description=description;
        this.soldout=soldout;
    }
    public Product(int id) {
        this.id = id;
    }

    public Product(String productName,String price,String quantity) {
        int pri = Integer.parseInt(price);
        int qty = Integer.parseInt(quantity);
        this.productName=productName;
        this.price=pri;
        this.quantity=qty;
    }

    public Product(String name,int price,int size){
        this.name =name;
        this.price = price;
        this.size1 = size;
    }
    public String getProductName(){
        return productName;
    }
    public int getPrice(){
        return price;
    }
    public int getId() {
        return id;
    }
    public String getDescription() {
        return description;
    }public List getSize(){
        return size;
    }
    public int getQuantity() {
        return quantity;
    }
    
}
