/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DAO.Product;
import DAO.User;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.util.ArrayList;
import static java.util.Arrays.asList;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;

/**
 *
 * @author Boss
 */
public class CartDAO {

    public static MongoClientURI uri = new MongoClientURI("mongodb://user1234:pass1234@ds127704.mlab.com:27704/softdev");
    public static MongoClient mongoClient = new MongoClient(uri);
    public static DB database = mongoClient.getDB("softdev");
    public static DBCollection table = database.getCollection("cart");
    public User user = new User();

    public void insert(int sum) {
        DBCollection collectCart = database.getCollection("cart");
        DBCollection collectOrderFind = database.getCollection("order"); //collection สำหรับค้นหา
        MongoDatabase database1 = mongoClient.getDatabase("softdev");
        MongoCollection collectOrderInsert = database1.getCollection("order"); // collection สำหรับเพิ่มข้อมูล
        BasicDBObject query = new BasicDBObject();
        query.put("username", user.getUsername());
        DBCursor cursor = collectCart.find(query);
        int num = collectOrderFind.find().count();
        List<Document> Data = new ArrayList<Document>();
        num++;
        //System.out.print(num);

        Document order = new Document("_id", num + "")
                .append("username", user.getUsername())
                .append("grandtotal", sum)
                .append("payment status", "X")
                .append("shipping status", "X");
        //int c=0;
        while (cursor.hasNext()) {
            DBObject x = cursor.next();
            ObjectId id = (ObjectId) x.get("_id");
            String productname = x.get("name").toString();
            int size = (int) x.get("size");
            int quantity = (int) x.get("quantity");
            int price = (int) x.get("price");
//            c++;

            Data.add(new Document("_id", id)
                    .append("name", productname)
                    .append("price", price)
                    .append("size", size)
                    .append("quantity", quantity)
                    .append("subtotal", quantity * price)
            );
            order.put("Product", Data);
        }
        //System.out.print(c);
        collectOrderInsert.insertMany(asList(order));
    }

    public void delete() {
        DBCollection collection = database.getCollection("cart");
        BasicDBObject query = new BasicDBObject();
        query.append("username", user.username);
        DBCursor cursor = collection.find(query);
        while (cursor.hasNext()) {
            DBObject x = cursor.next();
            collection.remove(x);
        }
    }

    public ArrayList<Cart> getCart() {
        ArrayList<Cart> arr = new ArrayList<>();
        DBCursor cursor = table.find();
        while (cursor.hasNext()) {
            DBObject ob = cursor.next();
            arr.add(new Cart((String) ob.get("name"), (int) ob.get("size"), (int) ob.get("price"), (int) ob.get("quantity")));
        }
        return arr;
    }

    public Cart findCart(String name) {
        ArrayList<DBObject> arr = new ArrayList<>();
        BasicDBObject searchQuery = new BasicDBObject();
        searchQuery.append("name", name);
        DBCursor cursor = table.find(searchQuery);

        DBObject ob = cursor.next();
        int size = Integer.parseInt(ob.get("size").toString());
        int price = Integer.parseInt(ob.get("price").toString());
        int qty = Integer.parseInt(ob.get("quantity").toString());
        Cart c1 = new Cart(new Product(ob.get("name").toString(), price, size), qty);

        return c1;

    }

    public void editCartByName(String name, int qty) {
        try {
            BasicDBObject search = new BasicDBObject();
            BasicDBObject edit = new BasicDBObject();
            search.put("name", name);
            edit.put("quantity", qty);
            BasicDBObject updateObj = new BasicDBObject();
            updateObj.put("$set", edit);
            table.update(search, updateObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCartByName(String name) {
        try {
            BasicDBObject searchQuery = new BasicDBObject();
            searchQuery.put("name", name);
            table.remove(searchQuery);
        } catch (Exception e) {

        }
    }

    public int getSum() {
        int sum = 0;
        DBCursor cursor = table.find();
        while (cursor.hasNext()) {
            DBObject ob = cursor.next();
            int price = Integer.parseInt(ob.get("price").toString());
            int qty = Integer.parseInt(ob.get("quantity").toString());
            sum += (price * qty);
        }
        return sum;
    }
}
