package DAO;
import DAO.User;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Boss
 */
public class OrderDAO {
    public static MongoClientURI uri = new MongoClientURI("mongodb://user1234:pass1234@ds127704.mlab.com:27704/softdev");
    public static MongoClient mongoClient = new MongoClient(uri);
    public static DB database = mongoClient.getDB("softdev");
    
    public DefaultTableModel getOrderByUsername(User user){
        try{
            DBCollection collection = database.getCollection("order");
            BasicDBObject query = new BasicDBObject();
            query.put("username", user.getUsername());
            DBCursor cursor = collection.find(query);
            String[] columnname={"No","Username","Grandtotal","Payment Status","Shipping Status"};
            DefaultTableModel model = new DefaultTableModel(columnname,0);
            while(cursor.hasNext()){
                DBObject obj = cursor.next();
                String no=(String) obj.get("_id").toString();
                String username=(String) obj.get("username").toString();
                String subtotal=(String) obj.get("grandtotal").toString();
                String payment=(String) obj.get("payment status").toString();
                String shipping=(String) obj.get("shipping status").toString();
                
                model.addRow(new Object[] {no,username,subtotal,payment,shipping});
            }
            return model;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
    
    public User getProfile(User user){
        try {
            DBCollection collection = database.getCollection("user");
            BasicDBObject query = new BasicDBObject();
            query.put("username", user.getUsername());
            query.put("password", user.getPassword());
            DBCursor cursor = collection.find(query);
            String fname = (String) cursor.one().get("firstname");
            String lanme = (String) cursor.one().get("lastname");
            String tel = (String) cursor.one().get("telephone");
            String address = (String) cursor.one().get("address");
            user = new User(user.getUsername(), user.getPassword(), fname, lanme,
                    tel, address);
            return user;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
