package DAO;

import DAO.Product;
import java.util.ArrayList;

public class OrderDetail {
    public String name;
    public int size;
    public int price;
    public int qty;
    public int subtotal;
    public static int grandtotal;
    public int sum;
    ArrayList<Product> product = new ArrayList<>();
    
    public OrderDetail(Product product,int qty){
        this.name = name;
        this.size = size;
        this.price = price;
        this.qty = qty;
        this.subtotal = subtotal;
        this.grandtotal = grandtotal;
    }

    public OrderDetail(String name, int size, int quantity, int price, int subtotal) {
        this.name = name;
        this.size = size;
        this.price = price;
        this.qty = quantity;
        this.subtotal = subtotal;
    }

    public OrderDetail(String name, int size, int price, int qty) {
        this.name = name;
        this.size = size;
        this.price = price;
        this.qty = qty;
        this.sum=price*qty;
    }
    
    public int getQTY(){
        return qty;
    }public String getName(){
        return name;
    }public int getSize(){
        return size;
    }public int getPrice(){
        return price;
    }public int getQuantity(){
        return qty;
    }public int getSubtotal(){
        return subtotal;
    }
    
    public OrderDetail(){
        
    }

    public int getSum() {
        return sum;
    }

    
}
