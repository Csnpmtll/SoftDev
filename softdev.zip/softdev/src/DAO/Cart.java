/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DAO.Product;
import java.util.ArrayList;

/**
 *
 * @author Boss
 */
public class Cart {
    //public Product product;
    public String name;
    public int size;
    public int qty;
    public int price;
    public int total;
    
     ArrayList<Product> product = new ArrayList<>();
    
    public Cart(Product product,int qty){
        this.name = product.name;
        this.size = product.size1;
        this.price = product.price;
        this.qty =qty; 
    }
    public Cart(){
        
    }
    public Cart(String name,int size,int price,int qty){
        this.name = name;
        this.size = size;
        this.price = price;
        this.qty =qty; 
    }
  
    public int getQty(){
        return qty;
    }
   
    
    
}
