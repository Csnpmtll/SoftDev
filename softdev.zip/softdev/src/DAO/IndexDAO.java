/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Boss
 */
public class IndexDAO {

    public static MongoClientURI uri = new MongoClientURI("mongodb://user1234:pass1234@ds127704.mlab.com:27704/softdev");
    public static MongoClient mongoClient = new MongoClient(uri);
    public static DB database = mongoClient.getDB("softdev");
    private static String s;
    public ArrayList<Product> getPopularProductDetail() {
        try {
            DBCollection collection = database.getCollection("product");
            DBCursor cursor = collection.find();
            cursor.sort(new BasicDBObject("soldout", -1));
            ArrayList<Product> pd = new ArrayList<>();
            while (cursor.hasNext()) {
                DBObject obj = cursor.next();
                int id=(int) obj.get("_id");
                String productName=(String) obj.get("name");
                List size=(List) obj.get("size");
                int quantity=(int) obj.get("quantity");
                int price=(int) obj.get("price");
                String description=(String) obj.get("description");
                int soldout=(int) obj.get("soldout");
                pd.add(new Product(id,productName,size,quantity,price,description,soldout));
            }
            return pd;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public GridFSDBFile getImage(String productName) throws IOException{
        GridFS fs = new GridFS(database,"photo");
        //Save loaded image from database into new image file
        GridFSDBFile imageForOutput = fs.findOne(productName);
        return imageForOutput;
    }
}
