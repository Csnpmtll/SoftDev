package DAO;

import DAO.Product;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import DAO.CartDAO;
import static DAO.CartDAO.mongoClient;
import static DAO.ProductDAO.database;
import com.mongodb.BasicDBList;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static java.util.Arrays.asList;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;

public class OrderDetailDAO {

    public static MongoClientURI uri = new MongoClientURI("mongodb://user1234:pass1234@ds127704.mlab.com:27704/softdev");
    public static MongoClient mongoClient = new MongoClient(uri);
    public static DB database = mongoClient.getDB("softdev");
    public static DBCollection table = database.getCollection("orderdetail");

    public ArrayList<OrderDetail> getDetail(String id) {
        DBCollection collection = database.getCollection("orderdetail");
        BasicDBObject query = new BasicDBObject();
        query.put("orderid",Integer.parseInt(id));
        DBCursor cursor = collection.find(query);
        ArrayList<OrderDetail> od = new ArrayList<>();
        while (cursor.hasNext()) {
            DBObject obj = cursor.next();
            String productName = (String) obj.get("name");
            int price = (int) obj.get("price");
            int size = (int) obj.get("size");
            int quantity = (int) obj.get("quantity");         
            int subtotal = (int) obj.get("subtotal");
            od.add(new OrderDetail( productName, size, quantity, price, subtotal));
        }
        return od;
    }

//    public OrderDetail FindOrderDetail(String name,ArrayList<OrderDetail> x) {
//        ArrayList<DBObject> arr = new ArrayList<>();
//        BasicDBObject searchQuery = new BasicDBObject();
//        searchQuery.append("name", name);
//        DBCursor cursor = table.find(searchQuery);
//        DBObject ob = cursor.next();
//        int size = (int) ob.get("size");
//        int price = (int) ob.get("price");
//        int qty = (int) ob.get("quantity");
//        OrderDetail OD = new OrderDetail(ob.get("name").toString(), price, size, qty);
//        return OD;
//    }
//
//    public int getSum() {
//        int sum = 0;
//        DBCursor cursor = table.find();
//        while (cursor.hasNext()) {
//            DBObject ob = cursor.next();
//            int price = Integer.parseInt(ob.get("price").toString());
//            int qty = Integer.parseInt(ob.get("quantity").toString());
//            sum += (price * qty);
//        }
//        return sum;
//    }

    public void addDetail() {
        DBCollection orderde = database.getCollection("orderdetail");
        DBCollection order1 = database.getCollection("order");
        DBCollection cart = database.getCollection("cart");
        CartDAO cd = new CartDAO();
        int id = (order1.find().count()) + 1;
        BasicDBObject query = new BasicDBObject();
        query.put("username", cd.user.getUsername());
        DBCursor cursor = cart.find(query);
        BasicDBObject doc = new BasicDBObject();
        int i = orderde.find().count() + 1;
        while (cursor.hasNext()) {
            DBObject x = cursor.next();
            String productname = x.get("name").toString();
            int size = (int) x.get("size");
            int quantity = (int) x.get("quantity");
            int price = (int) x.get("price");
            doc.put("_id", i);
            doc.put("name", productname);
            doc.put("price", price);
            doc.put("size", size);
            doc.put("quantity", quantity);
            doc.put("subtotal", quantity * price);
            doc.put("orderid", id);
            orderde.insert(doc);
            i++;
        }
    }
}
