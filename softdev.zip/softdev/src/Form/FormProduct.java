package Form;

import DAO.Product;
import DAO.ProductDAO;
import DAO.User;
import Service.ProductService;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class FormProduct extends javax.swing.JFrame {

    ArrayList<Product> pd = new ArrayList<>();
    static ProductService pds = new ProductService();

    public static ArrayList<Product> arr;

    public int idd;
    public static String id;

    public FormProduct() {
        initComponents();

//        ProductDAO pdd = new ProductDAO();
//        arr = pdd.getProduct(idd);
//        ArrayList<Product> newpd = pds.setProduct(idd);
//        txt_ProductName.setText(arr.get(0).productName);
//        txt_Price.setText(arr.get(0).price + "");
//        txt_Description.setText(" " + arr.get(0).description);
//        pds.showProduct();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel = new javax.swing.JPanel();
        header = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        icon = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        search = new javax.swing.JTextField();
        searchBTN = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        cartIcon = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        product = new javax.swing.JPanel();
        txt_pic = new javax.swing.JLabel();
        txt_Description = new javax.swing.JLabel();
        detail = new javax.swing.JPanel();
        txt_ProductName = new javax.swing.JLabel();
        txt_Size = new javax.swing.JLabel();
        ComboBox_Size = new javax.swing.JComboBox<>();
        txt_Quantity = new javax.swing.JLabel();
        ComboBox_Quantity = new javax.swing.JComboBox<>();
        addToCartBtn = new javax.swing.JButton();
        txt_Price = new javax.swing.JLabel();
        txt_Price1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setMinimumSize(new java.awt.Dimension(1600, 900));
        setResizable(false);
        setSize(new java.awt.Dimension(1600, 900));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        panel.setRequestFocusEnabled(false);
        panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        header.setBackground(new java.awt.Color(255, 255, 255));
        header.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel1MouseClicked(evt);
            }
        });

        icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icon.png"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setText("Sportshop");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(icon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(icon)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE))
                .addContainerGap())
        );

        header.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));
        header.add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 40, 460, 50));

        searchBTN.setText("SEARCH");
        header.add(searchBTN, new org.netbeans.lib.awtextra.AbsoluteConstraints(982, 40, 170, 50));

        jButton1.setText("profile");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        header.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1423, 0, 177, 34));

        cartIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cart.png"))); // NOI18N
        cartIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cartIconMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(cartIcon)
                .addGap(0, 1, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(cartIcon)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        header.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1530, 50, 40, 40));

        panel.add(header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 120));

        menu.setBackground(new java.awt.Color(102, 102, 102));
        menu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setText("BASKETBALL");
        menu.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 70));

        jButton3.setText("FOOTBALL");
        menu.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 0, 330, 70));

        jButton4.setText("RUNNING");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        menu.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 0, 320, 70));

        jButton5.setText("FITNESS");
        menu.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 0, 300, 70));

        jButton6.setText("VOLLEYBALL");
        menu.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1330, 0, 270, 70));

        panel.add(menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 1600, 70));

        product.setBackground(new java.awt.Color(255, 255, 255));
        product.setPreferredSize(new java.awt.Dimension(1600, 750));
        product.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_pic.setBackground(new java.awt.Color(255, 255, 255));
        txt_pic.setAlignmentY(0.0F);
        txt_pic.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_pic.setPreferredSize(new java.awt.Dimension(415, 415));
        product.add(txt_pic, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 40, 600, 460));

        txt_Description.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_Description.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        txt_Description.setText("  ");
        txt_Description.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txt_Description.setPreferredSize(new java.awt.Dimension(1300, 150));
        product.add(txt_Description, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 530, -1, -1));

        detail.setBackground(new java.awt.Color(255, 255, 255));

        txt_ProductName.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        txt_ProductName.setText("ProductName");

        txt_Size.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_Size.setText("Choose your Size");

        ComboBox_Size.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "7", "8", "9", "10", "11", "12", "13" }));
        ComboBox_Size.setPreferredSize(new java.awt.Dimension(200, 50));
        ComboBox_Size.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBox_SizeActionPerformed(evt);
            }
        });

        txt_Quantity.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_Quantity.setText("Choose your Quantity");

        ComboBox_Quantity.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        ComboBox_Quantity.setPreferredSize(new java.awt.Dimension(200, 50));
        ComboBox_Quantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBox_QuantityActionPerformed(evt);
            }
        });

        addToCartBtn.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        addToCartBtn.setText("ADD TO CART");
        addToCartBtn.setPreferredSize(new java.awt.Dimension(150, 75));
        addToCartBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addToCartBtnActionPerformed(evt);
            }
        });

        txt_Price.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N

        txt_Price1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        txt_Price1.setText("Price :");

        javax.swing.GroupLayout detailLayout = new javax.swing.GroupLayout(detail);
        detail.setLayout(detailLayout);
        detailLayout.setHorizontalGroup(
            detailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(detailLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(detailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_ProductName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(detailLayout.createSequentialGroup()
                        .addGroup(detailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addToCartBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(detailLayout.createSequentialGroup()
                                .addComponent(txt_Price1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_Price, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txt_Size, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ComboBox_Size, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ComboBox_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(70, Short.MAX_VALUE))))
        );
        detailLayout.setVerticalGroup(
            detailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(detailLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txt_ProductName)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(detailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_Price1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_Price, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(txt_Size, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ComboBox_Size, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txt_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(ComboBox_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(addToCartBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
        );

        product.add(detail, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 50, 500, 470));

        panel.add(product, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 1600, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void ComboBox_SizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBox_SizeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBox_SizeActionPerformed

    private void ComboBox_QuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBox_QuantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBox_QuantityActionPerformed

    private void addToCartBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addToCartBtnActionPerformed
        Product prod=new Product(txt_ProductName.getText(),txt_Price.getText(),ComboBox_Quantity.getSelectedItem().toString());
        pds.checkQuantity(prod);
    }//GEN-LAST:event_addToCartBtnActionPerformed

    private void jPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseClicked
        ProductService pds = new ProductService();
        try {
            pds.showIndex();
            this.hide();
        } catch (IOException ex) {
            Logger.getLogger(FormProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jPanel1MouseClicked

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowClosed

    private void cartIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cartIconMouseClicked
        FormCart fc = new FormCart();
        fc.show();
        this.hide();
    }//GEN-LAST:event_cartIconMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        FormOrder form = new FormOrder();
        form.show();
        this.hide();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormProduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormProduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormProduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormProduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormProduct().setVisible(true);

            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JComboBox<String> ComboBox_Quantity;
    public static javax.swing.JComboBox<String> ComboBox_Size;
    private javax.swing.JButton addToCartBtn;
    private javax.swing.JLabel cartIcon;
    private static javax.swing.JPanel detail;
    private javax.swing.JPanel header;
    private javax.swing.JLabel icon;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel panel;
    private javax.swing.JPanel product;
    private javax.swing.JTextField search;
    private javax.swing.JButton searchBTN;
    public javax.swing.JLabel txt_Description;
    public static javax.swing.JLabel txt_Price;
    private javax.swing.JLabel txt_Price1;
    public static javax.swing.JLabel txt_ProductName;
    private javax.swing.JLabel txt_Quantity;
    private javax.swing.JLabel txt_Size;
    public javax.swing.JLabel txt_pic;
    // End of variables declaration//GEN-END:variables
}
