package Service;

import DAO.Cart;
import DAO.CartDAO;
import DAO.ProductDAO;
import DAO.User;
import com.mongodb.DBObject;
import java.util.ArrayList;

/**
 *
 * @author Boss
 */
public class CartService {

    CartDAO dao = new CartDAO();
    ProductDAO product = new ProductDAO();

    public void addToOrder(int sum1) {
        dao.insert(sum1);
    }

    public void deleteCart() {
        dao.delete();
    }

    public ArrayList<Cart> getCart() {
        ArrayList<Cart> arr = new ArrayList<>();
        arr = dao.getCart();
        return arr;
    }

    public Cart findCart(String name) {
        Cart c1 = new Cart();
        c1 = dao.findCart(name);
        return c1;
    }

    public void editCartByName(String name, int qty) {
        dao.editCartByName(name, qty);
    }

    public void deleteCartByName(String name) {
        dao.deleteCartByName(name);
    }

    public int getSum() {
        return dao.getSum();
    }
}
