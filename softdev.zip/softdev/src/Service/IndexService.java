/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;
import DAO.Product;
import java.util.ArrayList;
import DAO.IndexDAO;
import com.mongodb.BasicDBObject;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
/**
 *
 * @author Boss
 */
public class IndexService {
    IndexDAO ID = new IndexDAO();
    
    
    public ArrayList<Product> getPopularProduct(){
        return ID.getPopularProductDetail();
    }
    public GridFSDBFile setImage(String productName) throws IOException{
        return ID.getImage(productName);
    }
    
    
}
