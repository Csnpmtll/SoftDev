package Service;

import javax.swing.table.DefaultTableModel;
import DAO.OrderDAO;
import DAO.User;
import javax.swing.JOptionPane;
    
public class OrderService {
    OrderDAO dao = new OrderDAO();
    
    public DefaultTableModel showOrderlist(User user){
        return dao.getOrderByUsername(user);
    }
    
    public void setProfile(User user){
        dao.getProfile(user);
    }
}
