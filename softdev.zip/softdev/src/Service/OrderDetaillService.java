
package Service;
import DAO.OrderDetail;
import DAO.OrderDetailDAO;
import DAO.ProductDAO;
import java.util.ArrayList;

/**
 *
 * @author Boss
 */
public class OrderDetaillService {
    OrderDetailDAO orderdetail = new OrderDetailDAO();
    ProductDAO product = new ProductDAO();
    
    public ArrayList<OrderDetail> getOrderDetail(String id){
        ArrayList<OrderDetail> arr = orderdetail.getDetail(id);
        return arr;
    }
    public OrderDetail FindOrderDetail(String name,ArrayList<OrderDetail> x){
        OrderDetail od = new OrderDetail();
        for(int i=0;i<x.size();i++){
            if(x.get(i).name.equals(name)){
                od=new OrderDetail(name,x.get(i).size,x.get(i).price,x.get(i).qty);
            }
        }return od;
    }

    public void addOrderDetail() {
        orderdetail.addDetail();
    }
    
}
