/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import DAO.Product;
import DAO.ProductDAO;
import Form.FormIndex;
import Form.FormProduct;
import static Form.FormProduct.arr;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ProductService {
    
    public ArrayList<Product>  setProduct(int id) {
        ProductDAO pdd = new ProductDAO();
        ArrayList<Product> apd = pdd.getProduct(id);
        return apd;

    }

    public static void showProduct(int x) {
        FormProduct product = new FormProduct();
        product.setVisible(true);
    }

    public static void showIndex() throws IOException {
        FormIndex index = new FormIndex();
        index.show();

    }
    public void checkQuantity(Product product){
        ProductDAO pdd = new ProductDAO();
        int count = pdd.checkProductQuantity(product);
        if(showMessage(count,product))
            pdd.addToCart(product);
    }
    public boolean showMessage(int count,Product product){
        if(count<=0){
            JOptionPane.showMessageDialog(null, "สินค้าหมด");
            return false;
        }else if(count>=product.getQuantity()){
            JOptionPane.showMessageDialog(null, "เพิ่มสินค้าใส่ตะกร้าสำเร็จ");
            return true;
        }else{
            JOptionPane.showMessageDialog(null, "สินค้าหมด");
            return false;
        }
    }
}
